<?php defined('Zero') or die('Zero CMS.');

header('HTTP/1.1 '.$url->httpCode().' '.$url->httpMessage());
