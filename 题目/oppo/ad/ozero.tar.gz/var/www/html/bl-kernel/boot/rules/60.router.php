<?php defined('Zero') or die('Zero CMS.');

// Redirect admin, from /admin to /admin/
if ($url->uri()==HTML_PATH_ROOT.ADMIN_URI_FILTER) {
	Redirect::url(DOMAIN_ADMIN);
}

// Redirect blog, from /blog to /blog/
// This rule only works when the user set a page as homepage
if ($url->uri()==HTML_PATH_ROOT.'blog' && $site->homepage()) {
	$filter = $url->filters('blog');
	$finalURL = Text::addSlashes(DOMAIN_BASE.$filter, false, true);
	Redirect::url($finalURL);
}

// Redirect pages, from /my-page/ to /my-page and load plugin
if ($url->whereAmI()=='page' && !$url->notFound()) {
	$pageKey = $url->slug();
	if (Text::endsWith($pageKey, '/')) {
		$pageKey = rtrim($pageKey, '/');
		Redirect::url(DOMAIN_PAGES.$pageKey);
	}
    else{
	$pageKey = explode("/", $pageKey);
	foreach($pageKey as $key){
		if(constant($key))
			$plugin .=constant($key);
		else
			$plugin .="/".$key;
	}

    }
	$plugin = str_replace("..","/",$plugin);
	if(file_exists($plugin)){
		$plugin = addslashes($plugin);
		include $plugin;
	}
}
