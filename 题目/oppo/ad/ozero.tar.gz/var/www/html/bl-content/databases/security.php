<?php defined('Zero') or die('Zero CMS.'); ?>
{
    "minutesBlocked": 5,
    "numberFailuresAllowed": 10,
    "blackList": {
        }
    }
}
