<?php defined('Zero') or die('Zero CMS.'); ?>
{
    "numberOfDays": 7,
    "label": "Visits",
    "excludeAdmins": false,
    "position": 1
}