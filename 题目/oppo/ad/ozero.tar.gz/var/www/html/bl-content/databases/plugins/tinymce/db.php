<?php defined('Zero') or die('Zero CMS.'); ?>
{
    "position": 1,
    "toolbar1": "formatselect bold italic forecolor backcolor removeformat | bullist numlist table | blockquote alignleft aligncenter alignright | link unlink pagebreak image code",
    "toolbar2": "",
    "plugins": "code autolink image link pagebreak advlist lists textpattern table"
}