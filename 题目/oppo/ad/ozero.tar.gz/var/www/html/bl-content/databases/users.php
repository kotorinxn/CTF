<?php defined('Zero') or die('Zero CMS.'); ?>
{
    "admin": {
        "nickname": "Admin",
        "firstName": "Administrator",
        "lastName": "",
        "role": "admin",
        "password": "45a800503e21182bcccbe50d02cac6735e7e30ac",
        "salt": "5d75bb009b7c2",
        "email": "",
        "registered": "2018-09-09 00:00:00",
        "tokenRemember": "",
        "tokenAuth": "e755751aad57d58f8f992035caf24b5f",
        "tokenAuthTTL": "2009-03-15 14:00",
        "twitter": "",
        "facebook": "",
        "instagram": "",
        "codepen": "",
        "linkedin": "",
        "github": "",
        "gitlab": ""
    }
}