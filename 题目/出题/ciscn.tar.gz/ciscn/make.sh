gcc -fstack-protector-all -D_FORTIFY_SOURCE=2 -z now -o pwn pwn.c
